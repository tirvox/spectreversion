![Spectre](icon.png)

# Welcome to Spectre

**Spectre** — fast Lua executor for Roblox with a clean dark interface,
built-in editor, ScriptHub and multi-client support.

## Quick start

1. Launch **Roblox Player**
2. Press **Attach** in the editor toolbar — Spectre finds the client itself
3. Write your script and press **Execute**

## Links

- [Official Website](https://getspectre.ct.ws/)
- [Discord](https://discord.gg/bdwnJuCtD6)
- [Roblox](https://www.roblox.com)

## Tips

- Right-click a tab to **rename**, close or duplicate it
- Drag tabs to **reorder** them
- Right-click inside the editor for **Copy / Cut / Paste**
- Click the **Console** header to collapse it
- Your files live in `Workspace`, `Scripts` and `AutoExec` folders
- Press the `+` on any folder to create a file right there

*Made with Quorum API · WebView2 UI*
